#!/usr/bin/perl
# no_defs.pl
# Robert Paulsen
# IBM Linux Technology Center
#
# Add application(s) symbol requirements to the database.
#
#    Copyright 2001, IBM Corporation
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# September 5, 2001: First version

use strict;
use warnings;

use DBI;
use myDB;

my ($dbh,$sth,$sql,$ctr,$href);

# connect to the database
$dbh=myDB::connect();

# list the unsatisfied dependencies, if any
$sql="SELECT DISTINCT symName
   FROM symReq sr, object o, symbol s LEFT JOIN symProvider sp
   ON sr.symID=sp.symID
   WHERE sp.symID IS NULL
   AND sr.objID=o.objID
   AND sr.symID=s.symID
   ORDER BY BINARY symName";
$sth=$dbh->prepare($sql);
$sth->execute();
$ctr=$sth->rows();
print STDERR "$ctr undefined symbols.\n" if ($ctr);
while (my $objRow = $sth->fetchrow_hashref()) {
   printf "$$objRow{symName}\n";
}

# All done!
$dbh->disconnect();
exit (0);
