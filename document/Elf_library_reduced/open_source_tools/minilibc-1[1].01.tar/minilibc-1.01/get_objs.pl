#!/usr/bin/perl
# get_objs.pl
# Robert Paulsen
# IBM Linux Technology Center
#
# Create list of required object files for use by Makefile
# that builds mini library. This script is invoked by scan_apps.pl
#
#    Copyright 2001, IBM Corporation
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# September 5, 2001: First version

use strict;
use warnings;

use DBI;
use myDB;

my ($dbh);

# connect to the database
$dbh=myDB::connect();

# start with empty list
system("cat /dev/null > buildlibc/libc_objects");

# fetch all recorded applications
my $sql="SELECT appName from application";
my $aref=$dbh->selectall_arrayref($sql);

# do nothing if no apps recorded
if ( ! @{$aref} ) {
   print "No applications recorded\n";
   $dbh->disconnect();
   exit(0);
}

# print names of all recorded applications
print "\nProcessing application(s):\n";
foreach my $rowref (@{$aref}) {
   print "\t$$rowref[0]\n";
}

# get explicit app dependencies (list of objects); put in a temp file
$sql="SELECT DISTINCT CONCAT(objName,'.os') AS objName
   FROM appDep ad, symProvider sp, object o
   WHERE ad.symID=sp.symID
   AND sp.objID=o.objID
";
my $sth=$dbh->prepare($sql);
$sth->execute();
my $expl_count=$sth->rows();
open DEPFILE, ">temp$$";
while (my $objRow = $sth->fetchrow_hashref()) {
   print DEPFILE "$$objRow{objName}\n";
}
close DEPFILE;
$sth->finish();

# get implicit app dependencies; add them to the temp file
$sql="SELECT DISTINCT CONCAT(objName,'.os') AS objName
   FROM appDep ad, symProvider sp, dependency dep, object o
   WHERE ad.symID=sp.symID
   AND sp.objID=dep.depObjID
   AND dep.srcObjID=o.objID
";
$sth=$dbh->prepare($sql);
$sth->execute();
my $impl_count=$sth->rows();
open DEPFILE, ">>temp$$";
while (my $objRow = $sth->fetchrow_hashref()) {
   print DEPFILE "$$objRow{objName}\n";
}
close DEPFILE;
$sth->finish();

# sort temp file; put results in master$$
system("sort -u temp$$ > master$$");
system("rm temp$$");

# get fully qualified names of all object files in glibc;
# put the list into @stamps
my $GLIBCPATH=myCFG::glibcpath;
my @stamps=`find $GLIBCPATH -name "stamp.os" -print`;

# from @stamps, get the fully-qualified names of objects that are
# identified in master$$ as required libc objects; put the resulting list
# in "buildlibc/libc_objects"
system("cat /dev/null > temp$$");
foreach my $stamp (@stamps) {
   chomp($stamp);
   (my $local_dir=$stamp) =~ s/$GLIBCPATH\///;  # strip most path info
   $local_dir =~ s/stamp[.]os//;                # strip "stamp.os"
   my $new_lines="tr ' ' '\n'";        # will put each filename on its own line
   my $strip_path="sed 's/.*\\///'";   # will strip path info from filename
   (my $escaped_GLIBCPATH=$GLIBCPATH) =~ s/\//\\\//g;
   (my $escaped_local_dir=$local_dir) =~ s/\//\\\//g;
   my $add_path="sed 's/^/$escaped_GLIBCPATH\\/$escaped_local_dir/'";
   system("cat $stamp | $new_lines | sort | $strip_path | \
         join - master$$ | $add_path >> temp$$");
}
#system("cat temp$$ buildlibc/libc_objects.base | sort -u >> buildlibc/libc_objects");
system("cat temp$$ | sort -u >> buildlibc/libc_objects");
system("rm master$$");
system("rm temp$$");
my $numObjs=0+`cat buildlibc/libc_objects | wc -l`;# count lines (i.e. objects)

# list the libraries used
$sql="SELECT distinct libName
   FROM appDep ad, symProvider sp, dependency dep, object o, library l
   WHERE ad.symID=sp.symID
   AND sp.objID=dep.depObjID
   AND dep.srcObjID=o.objID
   AND o.libID=l.libID
";
my $ref=$dbh->selectcol_arrayref($sql);
if (defined $ref ) {
   print "Libraries needed:\n" if ( @{$ref}>0 );
   foreach my $libName (@{$ref}) {
      $libName =~ s/_pic$//;
      $libName .= ".so";
      print "\t$libName\n";
   }
}

# print summary
print "libc.so will be built with $numObjs objects.\n";
print "List of libc.so objects is in \"buildlibc/libc_objects\"\n";

# all done!
$dbh->disconnect();
