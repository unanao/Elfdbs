#!/usr/bin/perl
# find_symbol.pl
# Robert Paulsen
# IBM Linux Technology Center
#
# Find named symbol and show all the objects that require or provide it
#
#    Copyright 2001, IBM Corporation
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# September 3, 2001: First version

use strict;
use warnings;

use myCFG;

(my $symName)=@ARGV;

my $GLIBCPATH=myCFG::glibcpath;

system("nm -g -o $GLIBCPATH/*.o* 2>/dev/null | grep $symName");

foreach my $o_dir (glob("$GLIBCPATH/*")) {
   system("nm -g -o $o_dir/*.o* 2>/dev/null | grep $symName") if -d $o_dir;
}
