#!/usr/bin/perl
# scan_apps.pl
# Robert Paulsen
# IBM Linux Technology Center
#
# Add application(s) symbol requirements to the database.
#
#    Copyright 2001, IBM Corporation
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# September 5, 2001: First version

use strict;
use warnings;

use DBI;
use myDB;

my ($dbh);

# add symbol to "symbol" table, if not already there
# in any case, return its symID
sub add_symbol($) {
   (my $symName) = @_;
   $dbh->do("INSERT IGNORE INTO symbol SET symName='$symName'");
   $dbh->selectrow_array("SELECT symID from symbol WHERE symName='$symName'");
}

# report on symbols needed by application(s) but not provided in glibc
sub show_missing_symbols() {
   my $sql="SELECT DISTINCT symName
         FROM appDep ad, symbol s, application a LEFT JOIN symProvider sp
         ON ad.symID=sp.symID
         WHERE sp.symID IS NULL
         AND ad.symID=s.symID AND ad.appID=a.appID
      ";
   my $sth=$dbh->prepare($sql);
   $sth->execute();
   my $ctr=$sth->rows();
   print("Symbols referenced by the application(s) but not defined in glibc:\n")
      if ($ctr);
   while (my $row_ref = $sth->fetchrow_hashref()) {
      printf "\t%-25s\n", $$row_ref{symName};
   }
}

# scan one application
sub scan_one_app($) {
   (my $appPath)=@_;

   # get appName from appPath
   (my $appName=$appPath) =~ s/.*\///;

   # first, remove the app if it is already recorded
   my $sql="SELECT appID FROM application where path='$appPath'";
   my $appID=$dbh->selectrow_array($sql);
   if (defined $appID) {
      $dbh->do("DELETE FROM application WHERE appID=$appID");
      $dbh->do("DELETE FROM appDep WHERE appID=$appID");
   }

   # record the applications name and path; get its appID
   $dbh->do("INSERT INTO application SET appName='$appName',path='$appPath'");
   $sql="SELECT appID FROM application where path='$appPath'";
   $appID=$dbh->selectrow_array($sql);
   
   # record the applications symbol requirements
   my @lines=`nm -oguP $appPath`;
   my $count=0;
   foreach my $line (@lines) {
      # parse out the fields: app_name: symbol@version (we only want symbol)
      (my $symName)=$line =~ /\S+\s+(\S+)/;
      $symName =~ s/@.*//;                   # strip version info

      # Ensure symbol name is in "symbol" table; get its symID
      my $symID=add_symbol($symName);

      # add appID,symID to appDep table
      $dbh->do("INSERT IGNORE INTO appDep SET symID=$symID, appID=$appID");

      ++$count;
      # printf "Added symbol %6d $symName\n", $symID;
   }
   printf "%6d symbols found for $appPath\n", $count;
}

##########################################################################
#
# Execution starts here
#
##########################################################################

# connect to the database
$dbh=myDB::connect();

# record each application specified on the command line
print "\n";
print "Scanning application(s) for undefined symbols:\n";
foreach my $appPath (@ARGV) {
   scan_one_app($appPath);
}

# show symbols needed by application(s), but not provided by glibc
show_missing_symbols();

# all done!
$dbh->disconnect();

#
# now create list of object files for building the library
#
system("./get_objs.pl");
