# myDB.pm
# Robert Paulsen
# IBM Linux Technology Center
# September 5, 2001: First version
#
# Configuraqtion variables for the perl scripts
#
#    Copyright 2001, IBM Corporation
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#  September 10, 2001   First version

package myCFG;

use strict;

# location of glibc build tree (XXX CHANGE ME for your glibc build tree)
# WARNING: Do not use tilde (~) to represent home directory.
my $GLIBCPATH="/path/to/glibc-2.x.x";

# DB information (XXX CHANGE ME for different MySQL configurtion)
# (You probably don't need to change this)
my $RDBMS="mysql";
my $DBHOST="localhost";
my $DBNAME="glibc";
my $DBUSER="glibcuser";
my $DBPASS="password";

# exported functions to return the above data
sub rdbms() { return $RDBMS; }
sub dbhost() { return $DBHOST; }
sub dbname() { return $DBNAME; }
sub dbuser() { return $DBUSER; }
sub dbpass() { return $DBPASS; }
sub glibcpath() { return $GLIBCPATH; }

1;    # return true
