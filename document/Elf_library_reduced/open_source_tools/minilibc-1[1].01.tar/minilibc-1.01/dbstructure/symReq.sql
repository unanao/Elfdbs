CREATE TABLE symReq (
  objID int(10) NOT NULL default '0',
  symID int(10) NOT NULL default '0',
  PRIMARY KEY  (objID,symID),
  UNIQUE KEY symID (symID,objID)
)
