CREATE TABLE object (
  objID int(10) NOT NULL auto_increment,
  libID int(10) default NULL,
  objName varchar(60) NOT NULL,
  PRIMARY KEY  (objID),
  UNIQUE KEY (objName,libID)
)
