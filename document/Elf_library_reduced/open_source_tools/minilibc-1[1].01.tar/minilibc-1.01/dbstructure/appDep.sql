CREATE TABLE appDep (
  appID int(10) NOT NULL default '0',
  symID int(10) NOT NULL default '0',
  PRIMARY KEY  (symID,appID)
)
