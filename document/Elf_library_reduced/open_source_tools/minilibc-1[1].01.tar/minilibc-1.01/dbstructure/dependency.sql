CREATE TABLE dependency (
  srcObjID int(10) NOT NULL default '0',
  depObjID int(10) NOT NULL default '0',
  PRIMARY KEY  (srcObjID,depObjID),
  UNIQUE KEY depObjID (depObjID,srcObjID)
)
