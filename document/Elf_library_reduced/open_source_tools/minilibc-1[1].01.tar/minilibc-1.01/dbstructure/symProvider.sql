CREATE TABLE symProvider (
  symID int(10) NOT NULL default '0',
  objID int(10) NOT NULL default '0',
  symType char(1) default NULL,
  PRIMARY KEY  (symID,objID)
)
