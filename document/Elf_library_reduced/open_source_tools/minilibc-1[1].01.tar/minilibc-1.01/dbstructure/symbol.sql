CREATE TABLE symbol (
  symID int(10) NOT NULL auto_increment,
  symName varchar(255) default NULL,
  PRIMARY KEY  (symID),
  UNIQUE KEY (symName)
)
