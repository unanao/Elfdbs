CREATE TABLE library (
  libID int(10) NOT NULL auto_increment,
  libName varchar(255) default NULL,
  PRIMARY KEY  (libID)
)
