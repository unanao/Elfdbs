CREATE TABLE application (
  appID int(10) NOT NULL auto_increment,
  appName varchar(255) default NULL,
  path varchar(255) default NULL,
  PRIMARY KEY  (appID)
)
