#!/usr/bin/perl
# del_apps.pl
# Robert Paulsen
# IBM Linux Technology Center
# September 4, 2001: First version
#
# Delete application(s) from the database.
#
#    Copyright 2001, IBM Corporation
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

use strict;
use warnings;

use DBI;
use myDB;

my $dbh;

# delete a single aplication
sub delete_one_app($) {
   (my $appName)=@_;
   my $sql="SELECT appID from application WHERE appName='$appName'";
   my $appID=$dbh->selectrow_array($sql);
   if ( defined $appID ) {
      print "deleting app $appID, $appName\n";
      $dbh->do("DELETE FROM application WHERE appID=$appID");
      $dbh->do("DELETE FROM appDep WHERE appID=$appID");
   } else {
      print "application $appName not in datbase\n";
   }
}

############################################################################
#
# Execution starts here
#
############################################################################

# check for cmd line arg(s)
if ( 1 > @ARGV ) {
   print "Must specify at least one application:\n";
   print "\tdelApps app_name [ another ... ]\n";
   exit(1);
}

# Connect to the database.
$dbh=myDB::connect();

# delete each application on the command line
foreach my $appName (@ARGV) {
   delete_one_app($appName);
}

# All done!
$dbh->disconnect();

# rebuild buildlibc/libc_objects.master
system("./get_objs.pl");
