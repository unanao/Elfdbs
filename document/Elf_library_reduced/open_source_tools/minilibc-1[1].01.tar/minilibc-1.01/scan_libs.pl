#!/usr/bin/perl
# scan_libs.pl
# Robert Paulsen
# IBM Linux Technology Center
#
# Record symbol requirements and symbol providers in the database.
# Symbol requirements are recorded in the table "symReq".
# Symbol providers are recorded in the table symProvider".
# Using the above, determine inter-object dependencies and record them
# in the database table "dependency"
#
#    Copyright 2001, IBM Corporation
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# September 3, 2001: First version


use strict;
use warnings;

use DBI;
use myDB;
use myCFG;

my $GLIBCPATH=myCFG::glibcpath();
my ($dbh,$sth,$sql,$ctr,$href);

# add object to "object" table; return the objID
sub add_object($$) {
   (my $libid, my $objname) = @_;
   $dbh->do("INSERT INTO object SET objname='$objname',libid=$libid");
   $dbh->selectrow_array("SELECT objID FROM object
         WHERE objname='$objname' AND libid=$libid");
}

# add symbol to "symbol" table, if not already there; return the symID
sub add_symbol($) {
   (my $symname) = @_;
   $dbh->do("INSERT IGNORE INTO symbol SET symName='$symname'");
   $dbh->selectrow_array("SELECT symid FROM symbol
         WHERE symName='$symname'");
}

my $total_objects=0;
my $total_referenced=0;
my $total_defined=0;

# Process a single library
sub process_one_lib($) {
   (my $lib_a) = @_;                   # full name of *_pic.a library
   (my $libName=$lib_a)=~s/[.]a//;     # strip ".a" suffix
   $libName =~ s/\S+\///;              # strip path info

   my $objID;           # id of object currently being processed
   my $objCount=0;      # count 'em
   my $reqSymCount=0;   # count symbols required by an object
   my $proSymCount=0;   # count symbols provided by an object

   # some more variables for this subroutine
   my ($libID, $objName, $symID, $symName, $symType, $symSize);

   # put library into database and get back its libID
   $dbh->do("INSERT IGNORE INTO library SET libName='$libName'");
   $libID=$dbh->selectrow_array("SELECT libID FROM library
                                 WHERE libName='$libName'");
   printf "%6d %-20s ", $libID, $libName;

   # Use nm to extract object and symbol information for required symbols
   my $lastObject="";   # will add new entry to object table when this changes
   my @lines = `nm -ogP $lib_a`;
   my $sth1=$dbh->prepare("INSERT IGNORE INTO symReq SET symID=?, objID=?");
   my $sth2=$dbh->prepare("INSERT IGNORE INTO symProvider
                           SET symID=?, symType=?, objID=?");
   foreach my $line (@lines) {

      # Parse out the fields:  library:[object]: symbol type
      ($objName, $symName, $symType) =
         $line =~ /.+\[(.+)\]:\s(\S+)\s(\S+)\s/;
      if (! defined $objName || ! defined $symName || ! defined $symType) {
         print STDERR "failed to parse: $line\n";
         next;
      }
      $objName =~ s/[.].*//;  # strip suffix from object name
      $symName =~ s/@.*//;    # strip version info

      # Put newly found objects in "object" table; get its objID.
      if ( $objName ne $lastObject ) {
         $objID=add_object($libID,$objName);
         $lastObject=$objName;
         ++$objCount;
      }

      # Ensure symbol name is in "symbol" table; get its symID.
      $symID=add_symbol($symName);

      # Add required (undefined) symbol to "symReq" table, or
      # add provided (defined) symbol to "symProvider" table
      if ( $symType =~ m/U/ ) {           # undefined symbol
         $sth1->execute($symID, $objID);
         ++$reqSymCount;
      }
      else {                              # defined symbol
         $sth2->execute($symID, $symType,$objID);
         ++$proSymCount;
      }
   }
   $sth1->finish();
   $sth2->finish();
   printf "%7d %8d %8d\n", $objCount, $reqSymCount, $proSymCount;
   $total_objects+=$objCount;
   $total_referenced+=$reqSymCount;
   $total_defined+=$proSymCount;
}

##########################################################################
#
#  Execution starts here
#
##########################################################################

my $dbstructure="dbstructure";   # path to the database structure files

print "\nProcessing $GLIBCPATH\n";

# create database
$dbh=myDB::connect_no_database();
$dbh->do("DROP DATABASE IF EXISTS glibc");
$dbh->do("CREATE DATABASE glibc");
$dbh->do("USE glibc");

# create tables in the database. Each "*.sql" file in the
# $dbstructure directory contains an sql statement to create a table.
foreach my $sqlfile (glob("$dbstructure/*.sql")) {
   open SQL, "<$sqlfile" or die("Can't open $sqlfile: $!");
   my @sql=<SQL>;
   close SQL;
   $dbh->do("@sql");
}

# process each pic archive
my @picfiles= `find $GLIBCPATH -name "*_pic.a" -print`;
print "\nLooking through all libraries to find objects and symbols...\n";
printf "%6s %-20s %16s %8s\n", "", "", "undefined", "defined";
printf "%6s %-20s %7s %8s %8s\n",
   "lib ID","library name","objects","symbols","symbols";
foreach my $picfile (@picfiles) {
   chomp($picfile);
   process_one_lib($picfile);
}

# print totals
printf "%27s ------- -------- --------\n","";
printf "%27s %7d %8d %8d\n","totals:",$total_objects,$total_referenced,$total_defined;

#
# calculate object dependencies
#
print "\nFinding inter-object dependencies...\n";
print "-------- finding explicit dependencies...\n";

# Start fresh -- clear out the dependency table.
$dbh->do("DELETE FROM dependency");

# Create temporary tables for following chain of implicit dependencies.
# These are the same structure as the dependency table.
$dbh->do("DROP TABLE IF EXISTS workA");
$dbh->do("CREATE TEMPORARY TABLE workA (PRIMARY KEY (srcObjID,depObjID))
      TYPE=MyISAM SELECT * FROM dependency WHERE 1=0");
$dbh->do("DROP TABLE IF EXISTS workB");
$dbh->do("CREATE TEMPORARY TABLE workB (PRIMARY KEY (srcObjID,depObjID))
      TYPE=MyISAM SELECT * FROM dependency WHERE 1=0");

# Find explicit dependencies
# Put them into the dependency table as the beginnings of our final result
# (which is a list of all dependencies, explicit and implicit).
$sql="
   INSERT INTO dependency (srcObjID,depObjID)
   SELECT DISTINCT sp.objID, sr.objID
   FROM symReq sr, symProvider sp
   WHERE sr.symID=sp.symID
   AND sr.objID!=sp.objID
";
my $deps_exp=$dbh->do($sql);
my $grand_deps=$deps_exp;
printf "%8d explicit dependencies found\n", $deps_exp;

# remember these dependencies for finding first level of indirect dependencies
$dbh->do("INSERT INTO workA SELECT * FROM dependency");

my $work1st="workA";
my $work2nd="workB";
my $depsAccum=0;
my $pass=0;
print "-------- finding implicit dependencies...\n";
while (1) {

   # At start of each iteration, $work1st contains the list of dependencies
   # found on the prior iteration (or initialized before entry to loop).

   # Get next level of implicit dependencies and put into table $work2nd.
   $dbh->do("DELETE FROM $work2nd");   # prepare to get new dependencies
   $sql="
      INSERT INTO $work2nd (srcObjID,depObjID)
      SELECT DISTINCT sp.objID, w.depObjID
      FROM $work1st w, symProvider sp, symReq sr
      LEFT JOIN dependency d
      ON sp.objID=d.srcObjID AND w.depObjID=d.depObjID
      WHERE d.depObjID is NULL
      AND w.srcObjID=sr.objID
      AND sr.symID = sp.symID
      AND w.depObjID!=sp.objID
   ";
   my $deps_imp=$dbh->do($sql);
   $depsAccum+=$deps_imp;

   # all done if nothing new found this iteration
   last if $deps_imp==0;

   # If any new dependencies were found this iteration, put them into the
   # dependency table.  They are left in $work2nd (which will become
   # $work1st) as a basis for finding next level of dependencies on the
   # next loop iteration.
   $dbh->do("INSERT INTO dependency SELECT * from $work2nd");

   # work tables reverse their roles each pass
   ($work1st,$work2nd)=($work2nd,$work1st);

   # Print counters for this iteration
   my $total_imp+=$deps_imp;
   ++$pass;
   printf "%8d pass $pass\n", $deps_imp;
}
print "-------- \n";
printf "%8d implicit dependencies found\n", $depsAccum; $grand_deps+=$depsAccum;
printf "%8d total dependencies found\n", $grand_deps;

# all done!
$dbh->disconnect();
exit (0);
