#!/usr/bin/perl
# show_apps.pl
# Robert Paulsen
# IBM Linux Technology Center
#
# List the applications recorded in the database.
#
#    Copyright 2001, IBM Corporation
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# September 4, 2001: First version

use strict;
use warnings;

use DBI;
use myDB;

my ($dbh,$sql,$aref);

sub delete_one_app($) {
   (my $appName)=@_;
   $sql="SELECT appID from application WHERE appName='$appName'";
   my $appID=$dbh->selectrow_array($sql);
   if ( defined $appID ) {
      print "deleting app $appID, $appName\n";
      $dbh->do("DELETE FROM application WHERE appID=$appID");
      $dbh->do("DELETE FROM appDep WHERE appID=$appID");
   } else {
      print "application $appName not found\n";
   }
}

# Connect to the database.
$dbh=myDB::connect();

# show recorded applications
$aref=$dbh->selectall_arrayref("SELECT appName, path FROM application");
if (defined $aref) {
   if ( 1 > @{$aref} ) {
      print "No applications recorded. " .
         "Run scan_apps.pl to record application info.\n";
   } else {
      foreach my $row_ref (@{$aref}) {
         printf "%-20s $$row_ref[1]\n",$$row_ref[0];
      }
   }
} else {
   print "program error!\n";
}

# All done!
$dbh->disconnect();
