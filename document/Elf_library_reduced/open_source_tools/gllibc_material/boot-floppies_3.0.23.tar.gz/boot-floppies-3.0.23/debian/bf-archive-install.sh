#! /bin/sh
#
# boot-floppy installation script for the FTP maintainer
#   -- used to help moving files from Incoming to their proper destination
#
# BEFORE YOU USE THIS SCRIPT:
#  (a) make the directory where these disks will reside:
#      # mkdir dists/%dist%/main/disks-%arch%/%version%-YYYYMMDD
#
#  (b) make a symlink to 'current'
#      # ln %version%-YYYYMMDD dists/%dist%/main/images-%arch%/current
#
#  (c) move the files from Incoming into place, including this script
#
#  (d) run this script
#
