#!/bin/sh

# Run with `pwd` the source top.

image=$1

# Create the floppy image
dd if=/dev/zero of=$image bs=1024 count=1440
hformat -l "Debian/PowerPC" $image

# Put important files on it
hmount $image
hcopy powerpc-specials/miBoot/Finder.bin :
hcopy powerpc-specials/miBoot/System.bin :

hcopy -r linuxpmac.bin.gz :zImage

# There's no longer enough room on the HFS disk for this :(  No real loss.
#gzip -dc sys_mappmac.gz > .S
#hcopy -r .S :System.map
#rm -f .S

# Possibly unnecessary blessing
hattrib -b :

humount

# Boot block
dd if=powerpc-specials/miBoot/hfs-bootblock.b of=$image conv=notrunc


# And we're done!
