#DESC: Inter-User Communication Vehicle (IUCV) - available for VM guests only

# TODO: check if IUCV is available - how can we do this?

cat <<__EOF__
Please enter the name of the VM peer you want to connect to. If you want to
connect to multiple peers, separate the names by colons, e.g. tcpip:linux1
The standard TCP/IP server name on VM is TCPIP, on VIF it's $TCPIP.
Note: IUCV must be enabled in the VM user directory for this driver to work and
it must be set up on both ends of the communication. See "LINUX for S/390:
Device Drivers and Installation Commands" for details.
__EOF__

readln "IUCV peer(s): "

# TOOD: check if answer is valid

module_parm="iucv=$ans"
chandev_parm=""
chandev_module_parm=""
