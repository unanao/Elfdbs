/* 
 * Start a shell - used as replacement for /bin/login
 */

#include <unistd.h>

int main(int argc, char ** argv)
{
  chdir("/root");
  execl("/bin/sh", "-/bin/sh", 0);
  return 0;
}
