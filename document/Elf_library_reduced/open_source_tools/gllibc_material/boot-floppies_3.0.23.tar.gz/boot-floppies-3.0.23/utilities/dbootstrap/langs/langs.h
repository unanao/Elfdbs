#ifndef __LL_H
#define __LL_H

struct language_item {
    char *name;

    char *locale;
    char *font;
    char *acm;
    char *keymap;
    char *msgcat;
};

struct language_list_item {
    int d;
    void *p;
};

struct language_list {
    char *name;

    struct language_list_item items[0];
};

struct language_definition {
    char *ename;
    char *name;
    char *font;
    char *acm;
    char *hint;

    struct language_list *list;
};

    const struct language_definition *available_languages (void);

#endif
