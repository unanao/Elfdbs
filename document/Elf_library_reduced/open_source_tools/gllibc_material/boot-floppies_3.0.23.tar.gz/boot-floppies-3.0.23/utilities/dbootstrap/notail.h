#ifndef _NOTAIL
#define _NOTAIL

struct notail 
{
  char *mnt;

  struct notail *next;
};

int need_notail (char *);
int addnotail (char *);
  
  
#endif
