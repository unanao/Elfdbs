#! /bin/sh

# Default directory as of console-data package
keymap_dir=/usr/share/keymaps

# We expect keymaps to be compressed!
keymap_suffix=.kmap.gz

./bf-info keymaps | sort | uniq | while read l k
do
    if [ ! -r $keymap_dir/$k$keymap_suffix ]
    then
        echo "$k is missing in language $l"
    fi
done
