/*
 * There should be one value for each keyboard type
 */

#ifndef KBD_cs_CZ
#  define KBD_cs_CZ	1
#  define KBD_C		0
#endif
#ifndef KBD_fr_BE
#  define KBD_fr_BE	1
#  define KBD_C		0
#endif
#ifndef KBD_fr_CA
#  define KBD_fr_CA	1
#  define KBD_C		0
#endif
#ifndef KBD_de_DE
#  define KBD_de_DE	1
#  define KBD_C		0
#endif
#ifndef KBD_da_DK
#  define KBD_da_DK	1
#  define KBD_C		0
#endif
#ifndef KBD_dvorak
#  define KBD_dvorak	1
#  define KBD_C		0
#endif
#ifndef KBD_es_ES
#  define KBD_es_ES	1
#  define KBD_C		0
#endif
#ifndef KBD_fi_FI
#  define KBD_fi_FI	1
#  define KBD_C		0
#endif
#ifndef KBD_fr_FR0
#  define KBD_fr_FR0	1
#  define KBD_C		0
#endif
#ifndef KBD_fr_FR
#  define KBD_fr_FR	1
#  define KBD_C		0
#endif
#ifndef KBD_el_GR
#  define KBD_el_GR	1
#  define KBD_C		0
#endif
#ifndef KBD_hu_HU
#  define KBD_hu_HU	1
#  define KBD_C		0
#endif
#ifndef KBD_is_IS
#  define KBD_is_IS	1
#  define KBD_C		0
#endif
#ifndef KBD_it_IT
#  define KBD_it_IT	1
#  define KBD_C		0
#endif
#ifndef KBD_ja_JP
#  define KBD_ja_JP	1
#  define KBD_C		0
#endif
#ifndef KBD_no_NO
#  define KBD_no_NO	1
#  define KBD_C		0
#endif
#ifndef KBD_pl_PL
#  define KBD_pl_PL	1
#  define KBD_C		0
#endif
#ifndef KBD_pt_BR
#  define KBD_pt_BR	1
#  define KBD_C		0
#endif
#ifndef KBD_pt_BR2
#  define KBD_pt_BR2	1
#  define KBD_C		0
#endif
#ifndef KBD_pt_PT
#  define KBD_pt_PT	1
#  define KBD_C		0
#endif
#ifndef KBD_ru_RU
#  define KBD_ru_RU	1
#  define KBD_C		0
#endif
#ifndef KBD_sv_SE
#  define KBD_sv_SE	1
#  define KBD_C		0
#endif
#ifndef KBD_tr_TR
#  define KBD_tr_TR	1
#  define KBD_C		0
#endif
#ifndef KBD_en_UK
#  define KBD_en_UK	1
#  define KBD_C		0
#endif
#ifndef KBD_de_CH
#  define KBD_de_CH	1
#  define KBD_C		0
#endif

#ifndef KBD_C
#  define KBD_C		1
#endif


