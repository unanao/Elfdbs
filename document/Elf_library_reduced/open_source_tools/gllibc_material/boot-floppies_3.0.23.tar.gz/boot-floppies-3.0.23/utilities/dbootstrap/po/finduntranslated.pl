#!/usr/bin/perl
# (C)opyright Risko Gergely, 2000
# This program can be licensed with GPL v2 or above
# Written for the boot-floppy translators...

open (FILE,$ARGV[0]) || die("file '" . $ARGV[0] . "' cannot be opened\n");
$a=0;
$line=0;
while ($olvas=<FILE>)
{
    $line++;
    if ($olvas=~/^msgstr \"\"/)
    {
	$a=1;
    }
    if ($olvas=~/^\"/)
    {
	$a=0;
    }
    if (($a==1) && ($olvas=~/^\#:/))
    {
	$lin=$line-2;
	print "Untranslated message found at line $lin.\n";
	$a=0;
    }
}
close(FILE);
