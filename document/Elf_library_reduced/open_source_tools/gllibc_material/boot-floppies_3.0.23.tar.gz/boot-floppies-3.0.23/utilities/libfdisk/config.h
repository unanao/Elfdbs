#ifndef _config_h
#define _config_h

/* this defines which partition formats to include */
/* (BSD_DISKLABEL and SOLARIS_X86 are suboptions of MSDOS_PARTITION) */
#if !#cpu(mips) || ( #cpu(mips) && defined (MIPSEL))
/* mipsel uses MSDOS partiton tables on DECstations */
#define HAVE_MSDOS_PARTITION	1
#define HAVE_BSD_DISKLABEL	1
#define HAVE_SOLARIS_X86_PARTITION	1
#endif

#define HAVE_OSF_PARTITION	1

#if #cpu(sparc)
#define HAVE_SUN_PARTITION	1
#endif

#if #cpu(ia64)
#define HAVE_GPT_PARTITION	1
#endif

#if #cpu(m68k) || #cpu(powerpc)
#define HAVE_AMIGA_PARTITION	1
#define HAVE_ATARI_PARTITION	1
#define HAVE_MAC_PARTITION	1
#define HAVE_ACORN_PARTITION	1
#endif

#if #cpu(arm)
#define HAVE_ACORN_PARTITION	1
#endif

#define HAVE_LOOP_PARTITION	1

/* MSDOS and SGI partitions use the same partition type numbers, 
   thus, they conflict */
#ifndef HAVE_MSDOS_PARTITION
#define HAVE_SGI_PARTITION      1
#endif

#if #cpu(s390)
#define HAVE_IBM_PARTITION      1
#endif

#endif  /* _config_h */

