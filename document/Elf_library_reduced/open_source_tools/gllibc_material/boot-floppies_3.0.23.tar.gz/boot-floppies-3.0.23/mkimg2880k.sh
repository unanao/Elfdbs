#!/bin/sh

rm -f img2880k img2880k.gz
dd if=/dev/zero of=img2880k bs=1k count=2880
echo "drive e: file=\"img2880k\" cylinders=80 heads=2 sectors=36 mformat_only" > mkimg2880k.cfg
MTOOLSRC=mkimg2880k.cfg mformat e:
syslinux -s img2880k
gzip -9 img2880k
ls -la img2880k.gz
rm -f mkimg2880k.cfg
