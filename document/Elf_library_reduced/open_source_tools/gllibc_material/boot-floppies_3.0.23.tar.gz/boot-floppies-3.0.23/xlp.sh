#!/bin/sh

. ./common.sh

D=$tmpdir/xlp-$$
make_tmpdir $D

info "making extended language pack"

for i in $*; do
  cp utilities/dbootstrap/po/utf/${i}.trm $D/messages.$i
  info "  adding messages.$i"
done

( cd $D; tar cf - * ) | gzip > xlp.tgz

rm -rf $D
